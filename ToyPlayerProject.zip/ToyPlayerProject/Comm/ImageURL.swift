//
//  ImageURL.swift
//  ToyPlayerProject
//
//  Created by Admin iMBC on 1/24/24.
//

import Foundation
class ImageURL{
    static let BACK_IMAGE_BLUREFFECT = "https://m.imbc.com/images/img-default.png"
}
