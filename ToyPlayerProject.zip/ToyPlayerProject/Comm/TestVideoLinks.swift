//
//  TestVideoLinks.swift
//  ToyPlayerProject
//
//  Created by Admin iMBC on 1/17/24.
//

import Foundation
class TestVideoLinks{
    public static let link1 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    public static let link2 = "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
    public static let link3 = "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
}
